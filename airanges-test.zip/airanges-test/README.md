# buble-one
Visualisation of bubbles like cryptobubbles.net with random values.
