'use strict';
const express = require('express');
const path = require('path');

// Node 18+ ma globalny fetch; fallback dla starszych
const fetch = global.fetch ? global.fetch : ((...args) => import('node-fetch').then(({ default: f }) => f(...args)));

const app = express();
const PORT = process.env.PORT || 3000;

// Statyczne + health
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/api/health', (_req, res) => res.json({ ok: true }));

// ===== Helpers =====
function nyFormat(d, tz = 'America/New_York') {
  const p = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz, hour12: false,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  }).formatToParts(d).reduce((a, q) => (a[q.type] = q.value, a), {});
  return { date: `${p.year}-${p.month}-${p.day}`, time: `${p.hour}:${p.minute}:${p.second}` };
}

// TOP tickery z SlickCharts — zwracamy dokładnie `limit`
async function getTopTickers(limit) {
  const resp = await fetch('https://www.slickcharts.com/sp500', { headers: { 'User-Agent': 'airanges/1.0' } });
  if (!resp.ok) throw new Error(`SlickCharts HTTP ${resp.status}`);
  const html = await resp.text();
  const rx = /\/symbol\/([A-Za-z\.]+)"/g;
  const out = []; const seen = new Set(); let m;
  while ((m = rx.exec(html)) && out.length < limit) {
    const t = m[1];
    if (!seen.has(t)) { seen.add(t); out.push(t); }
  }
  if (!out.length) throw new Error('No S&P500 tickers scraped');
  return out.slice(0, limit);
}

// EOD historia z paginacją (desc)
async function fetchEodHistory(ticker, needed, apiKey) {
  const all = [];
  let next = null;
  const pageSize = 100;
  do {
    const url = `https://api-v2.intrinio.com/securities/${encodeURIComponent(ticker)}/prices` +
      `?sort_order=desc&page_size=${pageSize}` + (next ? `&next_page=${encodeURIComponent(next)}` : ``) +
      `&api_key=${apiKey}`;
    const r = await fetch(url);
    if (!r.ok) break;
    const j = await r.json();
    const rows = Array.isArray(j.stock_prices) ? j.stock_prices : [];
    all.push(...rows);
    next = j.next_page || null;
  } while (all.length < needed + 1 && next);
  return all;
}

// Hour: ostatnia dostępna zmiana z 15m barów (okno 60 min)
async function hourlyFrom15m(ticker, apiKey) {
  try {
    const end = new Date(), start = new Date(end.getTime() - 60*60*1000);
    const s = nyFormat(start), e = nyFormat(end);
    const url = `https://api-v2.intrinio.com/securities/${encodeURIComponent(ticker)}/prices/intervals` +
      `?interval_size=15m&source=delayed&timezone=America/New_York` +
      `&start_date=${s.date}&start_time=${s.time}&end_date=${e.date}&end_time=${e.time}` +
      `&split_adjusted=false&include_quote_only_bars=false&page_size=10&api_key=${apiKey}`;
    const r = await fetch(url);
    if (!r.ok) return { ticker, price: null, changePercent: null };
    const j = await r.json();
    const arr = Array.isArray(j.intervals) ? j.intervals : [];
    const last = arr.length ? arr[arr.length-1] : null;
    const price = last && typeof last.close === 'number' ? last.close : null;
    let changePercent = null;
    for (let i = arr.length-1; i >= 0; i--) {
      const v = arr[i];
      if (v && typeof v.change === 'number' && isFinite(v.change)) { changePercent = v.change * 100; break; }
    }
    return { ticker, price, changePercent };
  } catch { return { ticker, price: null, changePercent: null }; }
}

// EOD: porównanie do 1/5/21/252 sesji wstecz (z historią stronicowaną)
async function eodChangeByIndex(ticker, idx, apiKey) {
  try {
    const hist = await fetchEodHistory(ticker, idx, apiKey);
    if (!hist.length) return { ticker, price: null, changePercent: null };
    const latest = hist[0];
    const prev = hist.length > idx ? hist[idx] : hist[hist.length - 1];
    const price = (latest && typeof latest.close === 'number') ? latest.close : null;
    let changePercent = null;
    if (prev && typeof prev.close === 'number' && prev.close && typeof price === 'number') {
      changePercent = ((price - prev.close) / prev.close) * 100;
    }
    return { ticker, price, changePercent };
  } catch { return { ticker, price: null, changePercent: null }; }
}

// ===== API =====
app.get('/api/sp500', async (req, res) => {
  const apiKey = process.env.INTRINIO_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'INTRINIO_API_KEY missing' });

  const range = (req.query.range || 'day').toLowerCase();
  const limitParam = parseInt(req.query.limit, 10);
  const LIMIT = Math.max(1, Math.min(100, Number.isFinite(limitParam) ? limitParam : 10)); // domyślnie 10
  const CONCURRENCY = Math.min(LIMIT, 10);
  const compareMap = { day: 1, week: 5, month: 21, year: 252 };

  try {
    const tickers = await getTopTickers(LIMIT); // <<< tylko LIMIT spółek
    const out = [];

    if (range === 'hour') {
      for (let i = 0; i < tickers.length; i += CONCURRENCY) {
        // eslint-disable-next-line no-await-in-loop
        out.push(...await Promise.all(tickers.slice(i, i + CONCURRENCY).map(t => hourlyFrom15m(t, apiKey))));
      }
    } else {
      const idx = compareMap[range] ?? 1;
      for (let i = 0; i < tickers.length; i += CONCURRENCY) {
        // eslint-disable-next-line no-await-in-loop
        out.push(...await Promise.all(tickers.slice(i, i + CONCURRENCY).map(t => eodChangeByIndex(t, idx, apiKey))));
      }
    }

    // bezpieczeństwo: twarde przycięcie do LIMIT
    res.json(out.filter(x => x && x.ticker).slice(0, LIMIT));
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message || 'Failed to build S&P500 data' });
  }
});

// Fallback
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => console.log(`[airanges] listening on :${PORT}`));
