    /**
     * This script implements an interactive bubble field.
     *
     * Key changes from the original version:
     *  - The number of bubbles has been increased from the original but
     *    reduced from the previous version to around 150 for better
     *    readability and performance.
     *  - Bubbles spawn randomly across the screen (rather than in a tight
     *    cluster) and repel each other to settle into an even distribution.
     *  - Pairwise repulsion runs each frame to prevent overlaps and, in
     *    combination with random initial velocities, provides a gentle drift.
     *  - Mouse interaction is rewritten: bubbles no longer flee from the
     *    pointer; instead you can click and drag any bubble. Dragging applies
     *    a proportional force so the bubble chases your pointer with some
     *    inertia. While dragging, the bubble still repels others, pushing
     *    them aside naturally. Releasing a bubble dampens its velocity to
     *    avoid jittery oscillations.
     */

    const container = document.getElementById('bubble-container');
    const bubbles = [];
    // Track whether the animation loop has been started to avoid creating
    // multiple loops when new data is loaded.
    let animationStarted = false;
    // Current range for which data is displayed. Defaults to daily changes.
    let currentRange = 'day';
        // Number of bubbles to display. This value is replaced once we load
        // S&P 500 constituents from the server. Defaults to 100 if the
        // request fails.
        let numBubbles = 100;

        // Track the maximum absolute percent change across all stocks. This is
        // used to scale bubble sizes proportionally so that the largest
        // percentage change corresponds to the largest bubble. It will be
        // computed once stock data is loaded.
        let maxAbsChange = 1;

    // When stock data is loaded from the server, it will be stored here.
    let stockData = null;
    // Base strength of inter‑bubble repulsion. A modest value causes bubbles
    // to separate gently without an explosive "blow‑apart" effect.  When a
    // bubble is actively dragged the repulsion force is temporarily
    // multiplied (see dragRepulsionMultiplier below) so that the dragged
    // bubble can more effectively push others aside. This base value
    // deliberately matches the earlier behaviour so un‑dragged bubbles
    // settle calmly.
    // Base repulsion strength between bubbles. Increasing this value will
    // make bubbles push each other apart more strongly. We slightly
    // increase it compared to the previous tuning to help dragged
    // bubbles clear a path through the field.
    const repulsionStrength = 0.08;
    // How much stronger the repulsion should be when one of the two
    // interacting bubbles is currently being dragged. A larger value
    // makes the dragged bubble act like a bull in a china shop, clearing
    // a path through neighbouring bubbles. We increase this from 4 to 6
    // so that a dragged bubble more effectively pushes aside its
    // neighbours.
    const dragRepulsionMultiplier = 6;
    // Reduce the repulsion applied to a bubble that has just been released
    // from a drag. While the "releasedCooldown" counter is greater than
    // zero, the repulsion force affecting that bubble will be scaled by
    // this factor. Lower values further suppress jitter after releasing a
    // bubble. We decrease this from 0.5 to 0.2 to damp residual
    // oscillations.
    const releasedRepulsionFactor = 0.2;
    // Friction factor to slow down bubbles over time. Lower friction
    // (closer to 0) means more damping. Increasing friction (closer to
    // 1) means less damping. We reduce friction slightly from 0.98 to
    // 0.96 so that velocities decay faster after interactions and
    // dragging, which should reduce post‑drag shaking.
    const friction = 0.96;
    // Amount of random jitter added to each bubble's velocity every frame
    // to simulate gentle drift. Keeping this small ensures a gentle
    // wandering motion across the viewport.
    const jitter = 0.03;

    /**
     * Generate a random hue for bubble colouring.
     * @returns {number}
     */
    function randomHue() {
      return Math.floor(Math.random() * 360);
    }

    /**
     * Create a bubble DOM element and corresponding state object.
     * Initially position all bubbles near the centre of the viewport with a
     * small random offset so they will push apart under the repulsion force.
     * @returns {{el: HTMLElement, x: number, y: number, vx: number, vy: number, size: number}}
     */
    function createBubble(stock) {
      /*
       * Create a bubble DOM element and state object. If stock data
       * is provided, the bubble's size and colour depend on the
       * percentage change relative to the previous close. A larger
       * absolute change yields a larger bubble. Positive changes are
       * coloured green; negative changes red. The label shows the
       * ticker on the first line and the change percentage on the
       * second line. When no stock data is available, fall back to
       * random sizing, colour and a single random value.
       */
      let size;
      let changePercent = 0;
      let gradient;
      let borderColor;
      let tickerSpan = null;
      let pctSpan = null;
      if (stock && stock.ticker) {
        // Determine bubble size based on absolute daily percent change.
        changePercent = stock.changePercent || 0;
        const absChange = Math.abs(changePercent);
        const minSize = 40;
        const multiplier = 15;
        const maxSize = 350;
        size = minSize + multiplier * absChange;
        if (size > maxSize) size = maxSize;
        // Create formatted percentage string with sign and one decimal.
        const pctStr =
          (changePercent > 0 ? '+' : changePercent < 0 ? '' : '') +
          (isFinite(changePercent) ? changePercent.toFixed(1) + '%' : '0.0%');
        // Prepare gradient fills and border colours based on sign.
        if (changePercent >= 0) {
          gradient =
            'radial-gradient(circle at 30% 30%, hsla(120, 70%, 65%, 0.9), hsla(120, 70%, 35%, 0.7) 70%, transparent)';
          borderColor = 'hsl(120, 80%, 60%)';
        } else {
          gradient =
            'radial-gradient(circle at 30% 30%, hsla(0, 70%, 65%, 0.9), hsla(0, 70%, 35%, 0.7) 70%, transparent)';
          borderColor = 'hsl(0, 80%, 60%)';
        }
        // Create separate spans for ticker and percentage to allow
        // independent font sizing. Use a flex column layout to stack
        // them vertically in the bubble.
        tickerSpan = document.createElement('div');
        tickerSpan.textContent = stock.ticker;
        pctSpan = document.createElement('div');
        pctSpan.textContent = pctStr;
      } else {
        // Fallback: random bubble with random size and colour.
        size = Math.random() * 120 + 50;
        const randomValue = (Math.random() * 100).toFixed(2);
        const hue = randomHue();
        gradient =
          'radial-gradient(circle at 30% 30%, ' +
          'hsla(' + hue + ', 90%, 70%, 0.8), ' +
          'hsla(' + hue + ', 90%, 50%, 0.6) 70%, transparent)';
        borderColor = 'hsl(' + hue + ', 80%, 60%)';
        tickerSpan = document.createElement('div');
        tickerSpan.textContent = randomValue;
        pctSpan = null;
      }
      // Generate starting positions and velocities.
      const startX = Math.random() * (window.innerWidth - size);
      const startY = Math.random() * (window.innerHeight - size);
      const vx = (Math.random() - 0.5) * 2;
      const vy = (Math.random() - 0.5) * 2;
      // Create the DOM element.
      const div = document.createElement('div');
      div.className = 'bubble';
      div.style.width = size + 'px';
      div.style.height = size + 'px';
      div.style.borderRadius = '50%';
      div.style.display = 'flex';
      div.style.flexDirection = 'column';
      div.style.alignItems = 'center';
      div.style.justifyContent = 'center';
      div.style.cursor = 'grab';
      div.style.userSelect = 'none';
      div.style.pointerEvents = 'auto';
      div.style.color = 'white';
      div.style.fontWeight = 'bold';
      div.style.textAlign = 'center';
      div.style.background = gradient;
      // Apply a border to mimic a neon ring.
      const borderThickness = size * 0.03;
      // border removed as requested
      // Ensure the bubble is draggable by explicitly setting pointer
      // events, cursor and user-select properties. Although these
      // properties are also defined in the CSS for .bubble, setting
      // them here avoids issues if the CSS is overridden or fails to
      // load.
      div.style.pointerEvents = 'auto';
      div.style.cursor = 'grab';
      div.style.userSelect = 'none';
      // Determine font sizes relative to the bubble size. Ticker uses
      // approximately 35% of the diameter, while the percentage uses 20%.
      // Determine font sizes relative to the bubble size. To avoid long
      // tickers overflowing, scale the ticker font down based on its
      // length. For tickers of three characters or fewer, use the
      // full 35 % of the diameter. For longer tickers, multiply by
      // 3/(length) so that, e.g., four characters use ~26 % and six
      // characters use ~17 %. The percentage text uses 20 % of the
      // diameter. Minimum font sizes ensure readability on tiny
      // bubbles.
      // Compute font sizes. Reduce the base percentage further for
      // smaller bubbles so that labels never overflow the circle.
      // Ticker font uses roughly 25% of the diameter for tickers up
      // to 3 characters. Longer tickers are scaled down by 3/len.
      // A lower minimum (8px) ensures the text remains inside very
      // small bubbles.
      let tickerSize;
      if (tickerSpan && stock && stock.ticker) {
        const len = stock.ticker.length;
        const scale = len > 3 ? (3 / len) : 1;
        tickerSize = Math.max(8, size * 0.25 * scale);
      } else {
        // In fallback mode, use a slightly reduced size since
        // the random number may have more digits than a typical ticker.
        tickerSize = Math.max(8, size * 0.24);
      }
      // Percentage text uses ~12% of the diameter with a lower
      // minimum to keep it inside small bubbles.
      const pctSize = Math.max(6, size * 0.12);
      // Assign computed font sizes. Also disable pointer events on
      // child spans so clicks always register on the bubble element,
      // allowing dragging even when clicking on text.
      tickerSpan.style.fontSize = tickerSize + 'px';
      tickerSpan.style.lineHeight = '1';
      tickerSpan.style.pointerEvents = 'none';
      div.appendChild(tickerSpan);
      if (pctSpan) {
        pctSpan.style.fontSize = pctSize + 'px';
        pctSpan.style.lineHeight = '1';
        pctSpan.style.pointerEvents = 'none';
        div.appendChild(pctSpan);
      }
      container.appendChild(div);
      return {
        el: div,
        x: startX,
        y: startY,
        vx: vx,
        vy: vy,
        size: size,
        changePercent: changePercent,
        releasedCooldown: 0
      };
    }

    // Populate the bubbles array.
    // In the stock mode we defer populating the bubbles until after
    // fetching data from the server. The `loadStockData` function will
    // build bubbles based on the downloaded data. If fetching fails,
    // this fallback block will be used to populate with random values.
    function populateFallback() {
      for (let i = 0; i < numBubbles; i++) {
        bubbles.push(createBubble());
      }
    }

    /**
     * Fetch the S&P 500 constituents and their realtime prices from our
     * server. The server proxies the Intrinio API and reads the API
     * key from an environment variable so the key remains secret. On
     * success, this will assign `stockData` and update `numBubbles` to
     * the length of the returned array. Then it will create bubbles
     * using each stock entry. If the fetch fails (e.g. due to
     * network/authorization errors), it will fall back to creating
     * random bubbles.
     */
    async function loadStockData(range = 'day') {
      try {
        const response = await fetch(`/api/sp500?range=${range}/api/sp500?range=${range}limit=10`);
        if (!response.ok) {
          throw new Error('Failed to fetch SP500 data');
        }
        const data = await response.json();
        // Use the returned array of {ticker, price} objects.
        stockData = Array.isArray(data) ? data : null;
        if (stockData && stockData.length > 0) {
          numBubbles = stockData.length;
          // Compute the maximum absolute change once so sizes are scaled
          // proportionally. Avoid division by zero by defaulting to 1 if all
          // values are zero or undefined.
          let maxVal = 0;
          for (const s of stockData) {
            const cp = Math.abs(s.changePercent || 0);
            if (cp > maxVal) maxVal = cp;
          }
          maxAbsChange = maxVal > 0 ? maxVal : 1;
          for (let i = 0; i < numBubbles; i++) {
            bubbles.push(createBubble(stockData[i]));
          }
        } else {
          // Fallback to random bubbles if data is empty.
          populateFallback();
        }
      } catch (err) {
        console.error(err);
        // Populate with random bubbles if an error occurs.
        populateFallback();
      }
      // Start the animation once bubbles are created. Only trigger the
      // loop the first time data is loaded.
      if (!animationStarted) {
        animationStarted = true;
        animate();
      }
    }

    // Remove all existing bubbles from the DOM so new data can be loaded.
    function resetBubbles() {
      bubbles.length = 0;
      container.innerHTML = '';
    }

    // Variables to track dragging state.
    let dragging = false;
    let draggedBubble = null;
    let dragOffsetX = 0;
    let dragOffsetY = 0;
    // Track the current mouse coordinates. These values are updated on every
    // mousemove event so we always know where the pointer is. Without this, using
    // window.event in the animation loop would not work reliably.
    let mouseX = 0;
    let mouseY = 0;

    // Detect if the browser supports PointerEvent. If pointer events are
    // available, we use them for all pointer interactions and ignore the
    // legacy mouse handlers to prevent duplicate drag logic on touch
    // devices (which can emit both pointer and mouse events).
    const usingPointerEvents = typeof window.PointerEvent !== 'undefined';

    /**
     * Find the bubble object for a given DOM element.
     * @param {HTMLElement} target
     * @returns {object|null}
     */
    function findBubbleByElement(target) {
      for (const bubble of bubbles) {
        if (bubble.el === target) {
          return bubble;
        }
      }
      return null;
    }

    // Handle mouse down to start dragging. Use closest() to ensure that
    // clicks on a bubble's child elements (like the ticker or
    // percentage spans) still start dragging. Without this, a click
    // on text would have e.target equal to a child div, and the
    // classList check would fail.
    container.addEventListener('mousedown', function (e) {
      if (usingPointerEvents) return;
      // Find the closest ancestor with class 'bubble'. If none is found,
      // the click was outside a bubble and dragging should not start.
      const bubbleEl = e.target.closest('.bubble');
      if (bubbleEl) {
        const bubble = findBubbleByElement(bubbleEl);
        if (bubble) {
          dragging = true;
          draggedBubble = bubble;
          // Mark the element for cursor change.
          bubble.el.classList.add('dragging');
          // Compute the offset between mouse position and bubble position to
          // maintain where inside the bubble the user clicked.
          const rect = bubble.el.getBoundingClientRect();
          dragOffsetX = e.clientX - rect.left;
          dragOffsetY = e.clientY - rect.top;
          // Prevent default to avoid text selection, etc.
          e.preventDefault();
        }
      }
    });

    // Track mouse movement to update the current pointer position. This ensures
    // we always have up‑to‑date coordinates when calculating drag forces. We attach
    // this to the container so movements outside a bubble still update the values.
    container.addEventListener('mousemove', function (e) {
      if (usingPointerEvents) return;
      mouseX = e.clientX;
      mouseY = e.clientY;
    });

  // --- Pointer events for touch and stylus support ---
  // On touch‑enabled or pen devices, allow dragging bubbles with a finger or
  // stylus. Pointer events unify mouse, touch and pen input under a single
  // API. These handlers mirror the mouse events above but work across
  // devices. The passive: false option on pointerdown allows calling
  // preventDefault() to stop default behaviours like scrolling.
  container.addEventListener('pointerdown', function (e) {
    const bubbleEl = e.target.closest('.bubble');
    if (bubbleEl) {
      const bubble = findBubbleByElement(bubbleEl);
      if (bubble) {
        dragging = true;
        draggedBubble = bubble;
        bubble.el.classList.add('dragging');
        const rect = bubble.el.getBoundingClientRect();
        dragOffsetX = e.clientX - rect.left;
        dragOffsetY = e.clientY - rect.top;
        // Capture the current pointer position immediately when grabbing the bubble
        // so the inertial force calculation starts from the touch point rather than
        // waiting for the first pointermove. Without this, the bubble may jerk
        // abruptly towards the last recorded mouse position on touch devices.
        mouseX = e.clientX;
        mouseY = e.clientY;

        // Capture subsequent pointer events on the container so we continue
        // receiving pointermove and pointerup events even if the pointer moves
        // outside the bubble container. This helps maintain smooth dragging on
        // touch devices when the finger crosses over the tab rows or other
        // elements.
        if (typeof container.setPointerCapture === 'function') {
          try {
            container.setPointerCapture(e.pointerId);
          } catch (err) {
            // ignore if capture fails (e.g. not supported)
          }
        }

        // Reset any residual velocity on the bubble when it is grabbed to avoid
        // an initial "kick" from previous motion. This mirrors the behaviour
        // implemented at pointerup/mouseup, ensuring a smooth start to the drag.
        bubble.vx = 0;
        bubble.vy = 0;

        // Prevent default to stop scrolling/pinching and ensure pointer events
        // are captured for dragging.
        e.preventDefault();
      }
    }
  }, { passive: false });

  // Listen for pointer movements on the window so the bubble continues to
  // follow the pointer even if it leaves the bubble container (e.g. when
  // crossing over the tab rows). Without this, the pointer coordinates
  // would stop updating when moving outside the container, causing the
  // dragged bubble to spring away from the finger on touch devices.
  window.addEventListener('pointermove', function (e) {
    mouseX = e.clientX;
    mouseY = e.clientY;
  });

  window.addEventListener('pointerup', function (e) {
    // Release pointer capture when the drag ends.
    if (typeof container.releasePointerCapture === 'function') {
      try {
        container.releasePointerCapture(e.pointerId);
      } catch (err) {
        // ignore if release fails
      }
    }
    if (dragging && draggedBubble) {
      draggedBubble.el.classList.remove('dragging');
      draggedBubble.vx = 0;
      draggedBubble.vy = 0;
      draggedBubble.releasedCooldown = 40;
    }
    dragging = false;
    draggedBubble = null;
  });

    // Handle mouse up to stop dragging.
    window.addEventListener('mouseup', function () {
      if (usingPointerEvents) return;
      if (dragging && draggedBubble) {
        draggedBubble.el.classList.remove('dragging');
        // When dragging ends, zero out the bubble's velocity and start a
        // cooldown period during which jitter is suppressed. This prevents
        // the bubble from wobbling back and forth after being released.
        draggedBubble.vx = 0;
        draggedBubble.vy = 0;
        // Set a cooldown period after dragging ends. During this time the
        // repulsion force on this bubble is reduced and jitter is
        // suppressed. Increase the number of frames to lengthen the
        // settling time. At 60fps, 40 frames ≈ 0.66s.
        draggedBubble.releasedCooldown = 40;
      }
      dragging = false;
      draggedBubble = null;
    });

    // Main animation loop. Applies forces, updates positions and DOM.
    function animate() {
      const width = window.innerWidth;
      const height = window.innerHeight;
      // Compute the container's offset relative to the viewport. We subtract
      // these values from the pointer coordinates so drag calculations use
      // positions relative to the container's coordinate system rather than
      // the page. Without this, adding header rows causes the bubble to
      // "jump" because mouseX/mouseY are relative to the viewport while
      // bubble.x/bubble.y are relative to the container.
      const containerRect = container.getBoundingClientRect();
      const containerOffsetX = containerRect.left;
      const containerOffsetY = containerRect.top;

      // Apply pairwise repulsion between all bubbles. This runs in O(n²), but
      // with 200 elements it's still performant in modern browsers. The
      // repulsion pushes overlapping or nearby bubbles apart.
      for (let i = 0; i < bubbles.length; i++) {
        const b1 = bubbles[i];
        for (let j = i + 1; j < bubbles.length; j++) {
          const b2 = bubbles[j];
          const dx = b1.x + b1.size / 2 - (b2.x + b2.size / 2);
          const dy = b1.y + b1.size / 2 - (b2.y + b2.size / 2);
          const distSq = dx * dx + dy * dy;
          const minDist = (b1.size + b2.size) / 2;
          // Only apply a force when bubbles are within repulsion range.
          if (distSq < (minDist * minDist)) {
            const dist = Math.sqrt(distSq) || 1;
            // Normalise direction vector.
            const ux = dx / dist;
            const uy = dy / dist;
            // Strength of force increases as bubbles get closer.
            const strength = (minDist - dist) / minDist;
            // Determine if either bubble is currently being dragged. If so,
            // multiply the base repulsion strength so the dragged bubble
            // more effectively clears a path through neighbours. Also
            // reduce the repulsion if one of the bubbles is in its
            // post‑release cooldown period to minimise jitter.
            let forceMultiplier = 1;
            if (draggedBubble && (b1 === draggedBubble || b2 === draggedBubble)) {
              forceMultiplier *= dragRepulsionMultiplier;
            }
            if (b1.releasedCooldown > 0 || b2.releasedCooldown > 0) {
              forceMultiplier *= releasedRepulsionFactor;
            }
            const force = repulsionStrength * strength * forceMultiplier;
            // Push each bubble away from the other.
            b1.vx += ux * force;
            b1.vy += uy * force;
            b2.vx -= ux * force;
            b2.vy -= uy * force;
          }
        }
      }

      bubbles.forEach(function (bubble) {
        // Add some random jitter to create a gentle drifting motion. Jitter
        // is omitted for the bubble being dragged (it follows the mouse) and
        // for a short period after a bubble is released to prevent shaking.
        if (bubble !== draggedBubble && bubble.releasedCooldown === 0) {
          bubble.vx += (Math.random() - 0.5) * jitter;
          bubble.vy += (Math.random() - 0.5) * jitter;
        } else if (bubble.releasedCooldown > 0) {
          // Decrement the cooldown counter each frame. When it reaches zero
          // jitter will resume for this bubble.
          bubble.releasedCooldown--;
        }

            // Previously, negative‑percentage bubbles drifted downward. To
            // simplify the behaviour so all bubbles move consistently, we no
            // longer apply a downward acceleration for losers. The natural
            // random jitter and repulsion will still provide gentle motion.

        // If this bubble is currently being dragged, apply a force that
        // accelerates it towards the mouse position. The offset keeps the
        // pointer relative to where it initially grabbed the bubble. The
        // multiplier controls how quickly the bubble catches up to the
        // pointer—lower values mean more inertia.
        if (dragging && bubble === draggedBubble) {
          // Compute the target position based on the current pointer coordinates,
          // subtracting both the original drag offset and the container's offset
          // within the viewport. This ensures the bubble is drawn relative
          // to its parent container even if there are header bars or other
          // elements above it.
          const targetX = mouseX - containerOffsetX - dragOffsetX;
          const targetY = mouseY - containerOffsetY - dragOffsetY;
          const dx = targetX - bubble.x;
          const dy = targetY - bubble.y;
          // Apply a proportional force towards the target. Lower values result in
          // more inertia; higher values make the bubble follow the pointer more
          // closely.
          // Reduce the follow strength so the bubble lags behind the pointer
          // and chases it, creating an inertia effect. Lower values increase
          // inertia; previously this was 0.2 which made the bubble snap too
          // quickly and oscillate on release.
          // Increase follow strength so the dragged bubble gains enough
          // momentum to push neighbouring bubbles aside while still
          // maintaining some inertia (it will lag slightly behind the pointer).
          // Lower followStrength makes the dragged bubble lag further behind
          // the pointer, increasing inertia. A higher value would make it
          // snap more quickly to the cursor. Here we choose 0.12 to
          // provide a noticeable delay while still allowing the bubble to
          // accelerate enough to push neighbours aside.
          // Strength of the pull towards the mouse while dragging. A
          // smaller value makes the dragged bubble chase the pointer
          // more slowly, increasing inertia. We reduce this from
          // 0.12 to 0.10 to give the bubble a bit more lag, which
          // allows it to build momentum and push through other bubbles
          // without snapping directly under the cursor.
          const followStrength = 0.10;
          bubble.vx += dx * followStrength;
          bubble.vy += dy * followStrength;
        }

        // Apply friction so bubbles eventually slow down.
        bubble.vx *= friction;
        bubble.vy *= friction;

        // Update position based on velocity.
        bubble.x += bubble.vx;
        bubble.y += bubble.vy;

        // Constrain bubbles within viewport boundaries. When a bubble hits
        // the edge, invert its velocity component and clamp its position
        // inside the bounds.
        if (bubble.x < 0) {
          bubble.x = 0;
          bubble.vx *= -1;
        }
        if (bubble.x + bubble.size > width) {
          bubble.x = width - bubble.size;
          bubble.vx *= -1;
        }
        if (bubble.y < 0) {
          bubble.y = 0;
          bubble.vy *= -1;
        }
        if (bubble.y + bubble.size > height) {
          bubble.y = height - bubble.size;
          bubble.vy *= -1;
        }

        // Update DOM element transform. Using translate for better performance.
        bubble.el.style.transform =
          'translate(' + bubble.x + 'px, ' + bubble.y + 'px)';
      });

      requestAnimationFrame(animate);
    }

    // Kick off the data loading process for the default range (day). This will
    // populate the `bubbles` array and start the animation when complete.
    // Without awaiting here, the browser continues to parse and event
    // handlers are attached immediately.
    loadStockData(currentRange);

    // ------------------------------------------------------------
    // Tab handling: highlight the selected tab and sub‑tab. The primary
    // tabs (AI Stocks and AI Crypto) currently show the same content but
    // are styled to indicate which is active. The secondary tabs
    // (godzina, dzień, tydzień, miesiąc, rok) likewise update their
    // active state when clicked. Additional logic to load different
    // datasets or adjust the time range can be added here in future.
    (function initTabs() {
      const primaryTabs = document.querySelectorAll('#primary-tabs .tab');
      primaryTabs.forEach((tab) => {
        tab.addEventListener('click', function () {
          const current = document.querySelector('#primary-tabs .active');
          if (current) current.classList.remove('active');
          this.classList.add('active');
          // TODO: Switch datasets or views based on data‑tab attribute.
        });
      });
      const secondaryTabs = document.querySelectorAll('#secondary-tabs .sub-tab');
      secondaryTabs.forEach((tab) => {
        tab.addEventListener('click', function () {
          const current = document.querySelector('#secondary-tabs .active');
          if (current) current.classList.remove('active');
          this.classList.add('active');
          const range = this.getAttribute('data-range');
          currentRange = range;
          resetBubbles();
          loadStockData(range);
        });
      });
    })();
